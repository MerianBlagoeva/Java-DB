package com.softuni.productshop.constants;

public class GlobalConstants {
    public static final String RESOURCES_FILE_PATH = "src/main/resources/files/";
}
