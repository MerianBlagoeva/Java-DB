package com.softuni.productshop.util;

public interface ValidationUtil {
    <E> boolean isValid(E entity);
}
