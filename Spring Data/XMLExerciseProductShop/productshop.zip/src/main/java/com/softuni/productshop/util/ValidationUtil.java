package com.softuni.productshop.util;

public interface ValidationUtil {
    <T> boolean isValid(T entity);
}
