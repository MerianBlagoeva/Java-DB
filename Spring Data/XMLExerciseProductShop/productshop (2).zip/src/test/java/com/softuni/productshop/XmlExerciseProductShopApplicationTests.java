package com.softuni.productshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlExerciseProductShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
