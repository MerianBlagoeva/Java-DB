package com.softuni.productshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlExerciseProductShopApplication {

    public static void main(String[] args) {
        SpringApplication.run(XmlExerciseProductShopApplication.class, args);
    }

}
