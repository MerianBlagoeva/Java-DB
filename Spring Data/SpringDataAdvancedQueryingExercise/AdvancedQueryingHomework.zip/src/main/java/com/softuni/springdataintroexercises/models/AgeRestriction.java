package com.softuni.springdataintroexercises.models;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
