package com.softuni.springdataintroexercises.models;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
