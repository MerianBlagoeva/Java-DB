package com.softuni.springdataintroexercises;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataIntroExercisesApplicationTests {

    @Test
    void contextLoads() {
    }

}
