package com.softuni.cardealer.service;

public interface SaleService {
    void seedSales();
}
