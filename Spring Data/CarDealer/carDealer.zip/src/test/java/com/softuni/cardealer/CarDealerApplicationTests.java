package com.softuni.cardealer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarDealerApplicationTests {

    @Test
    void contextLoads() {
    }

}
