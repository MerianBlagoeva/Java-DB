package softuni.exam.constants;

public class GlobalConstants {
    public static final String RESOURCES_JSON_FILE_PATH = "src/main/resources/files/json/";
    public static final String RESOURCES_XML_FILE_PATH = "src/main/resources/files/xml/";
}
