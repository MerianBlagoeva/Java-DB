package com.softuni.springdataintroexercises;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataIntroExercisesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataIntroExercisesApplication.class, args);
    }

}
