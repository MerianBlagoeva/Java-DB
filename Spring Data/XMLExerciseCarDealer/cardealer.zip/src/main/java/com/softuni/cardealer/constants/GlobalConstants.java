package com.softuni.cardealer.constants;

public class GlobalConstants {
    public static final String RESOURCES_FILE_PATH = "src/main/resources/files/";
    public static final String RESOURCES_OUT_PATH = "src/main/resources/files/out/";
}
