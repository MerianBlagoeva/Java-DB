package com.softuni.springautomapex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataAutoMappingObjectsExerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataAutoMappingObjectsExerciseApplication.class, args);
    }

}
