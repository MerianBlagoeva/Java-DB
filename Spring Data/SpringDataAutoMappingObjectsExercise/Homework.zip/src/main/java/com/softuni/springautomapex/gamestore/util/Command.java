package com.softuni.springautomapex.gamestore.util;

public interface Command {
    void run(String... args);
}
