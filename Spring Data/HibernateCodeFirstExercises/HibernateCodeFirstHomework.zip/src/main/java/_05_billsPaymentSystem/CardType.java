package _05_billsPaymentSystem;

public enum CardType {
    GOLD,
    SILVER
}
